package burp;

public interface IContextMenuInvocation {
    IHttpRequestResponse[] getSelectedMessages();
}