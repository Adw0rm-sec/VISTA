package burp;

import java.awt.Component;

public interface ITab {
    String getTabCaption();
    Component getUiComponent();
}