---
name: Feature request
about: Suggest an idea for this project
labels: enhancement
---

### Problem
What problem are you trying to solve?

### Proposed solution
Describe the feature you’d like.

### Alternatives
Any alternative solutions you’ve considered.

### Additional context
Add any other context or screenshots here.
